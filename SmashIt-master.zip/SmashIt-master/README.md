#Kahoot-Smasher

SmashIt - Kahoot Edition

This repository includes the source code of the app "SmashIt-Kahoot edition" which has since been removed from the Google Play store.
For all interested, here is the complete source code and assets.
Please understand that I have not spent time cleaning my code or adding meaningful comments so please be respectful.
Additionally, if you would like to modify my code or re-distribute my work please credit me in your adaptation and link to this page.
(I would also appreciate it if you contacted me beforehand at dev.programsofdaveduck@gmail.com)

I am not responsible for any misuse of this code as I provide it as an educational resource only

This project can be edited and compiled using andoid studio

Pre-complied version: https://www.mediafire.com/file/qzq7nwn4zw827oo/SmashIt.apk
